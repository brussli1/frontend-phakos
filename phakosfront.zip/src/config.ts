// src/config.js
export const baseURL = 'http://168.138.133.221:1337'; // Base URL of your Strapi instance
